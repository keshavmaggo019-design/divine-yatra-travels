const destinations = [
  ["Vrindavan", "Krishna bhakti lanes, ISKCON, Banke Bihari darshan.", "2 Days", "Rs. 2,499", "North", "🪷"],
  ["Mathura", "Birthplace temples, ghats, and evening aarti experiences.", "2 Days", "Rs. 2,299", "North", "🛕"],
  ["Kashi Vishwanath", "Sacred Ganga darshan with temple visits and guided walks.", "3 Days", "Rs. 4,999", "North", "🪔"],
  ["Ayodhya", "Ram Mandir, Sarayu aarti, and heritage sightseeing.", "3 Days", "Rs. 4,499", "North", "🏛"],
  ["Jagannath Puri", "Jagannath Temple, sea breeze, and cultural sightseeing.", "4 Days", "Rs. 7,999", "East", "🌊"],
  ["Haridwar", "Har Ki Pauri, Ganga aarti, and peaceful ghats.", "2 Days", "Rs. 3,499", "North", "🌅"],
  ["Rishikesh", "Ashrams, Ganga views, and spiritual calm.", "2 Days", "Rs. 3,799", "North", "🏞"],
  ["Kedarnath", "Mountain pilgrimage with assisted transfers and stays.", "6 Days", "Rs. 14,999", "Himalaya", "⛰"],
  ["Badrinath", "Char Dham route comfort with guided temple visits.", "6 Days", "Rs. 13,999", "Himalaya", "❄"],
  ["Gangotri", "Sacred source route with scenic Himalayan travel.", "5 Days", "Rs. 12,499", "Himalaya", "🌿"],
  ["Yamunotri", "Himalayan yatra with safe stops and support.", "5 Days", "Rs. 12,299", "Himalaya", "🌄"],
  ["Vaishno Devi", "Katra transfers, hotel stay, and darshan coordination.", "4 Days", "Rs. 8,499", "North", "⭐"],
  ["Somnath", "Jyotirlinga darshan with coastal Gujarat sightseeing.", "4 Days", "Rs. 8,999", "West", "🌞"],
  ["Dwarka", "Dwarkadhish Temple and Bet Dwarka spiritual tour.", "4 Days", "Rs. 9,499", "West", "🚩"],
  ["Shirdi", "Sai Baba darshan with comfortable overnight travel.", "3 Days", "Rs. 5,499", "West", "🙏"],
  ["Tirupati Balaji", "South India darshan package with hotel and meals.", "4 Days", "Rs. 8,999", "South", "🌺"]
];

const packages = [
  { name: "Vrindavan Weekend Tour", days: "2 Days / 1 Night", price: "Rs. 2,499", bus: "AC Pushback Bus", seats: 18, icon: "🪷" },
  { name: "Kashi Vishwanath Darshan", days: "3 Days / 2 Nights", price: "Rs. 4,999", bus: "Luxury AC Coach", seats: 12, icon: "🪔" },
  { name: "Ayodhya Ram Mandir Yatra", days: "3 Days / 2 Nights", price: "Rs. 4,499", bus: "AC Sleeper Coach", seats: 21, icon: "🏛" },
  { name: "Char Dham Comfort Circuit", days: "10 Days / 9 Nights", price: "Rs. 24,999", bus: "Premium Hill Coach", seats: 9, icon: "⛰" },
  { name: "Vaishno Devi Family Tour", days: "4 Days / 3 Nights", price: "Rs. 8,499", bus: "AC Semi-Sleeper", seats: 16, icon: "⭐" },
  { name: "Dwarka Somnath Journey", days: "5 Days / 4 Nights", price: "Rs. 11,999", bus: "Luxury AC Coach", seats: 14, icon: "🚩" }
];

const features = ["Affordable Prices", "Luxury AC Buses", "Experienced Drivers", "Safe Journey", "Comfortable Hotels", "Daily Refreshments", "Guided Temple Visits", "24x7 Customer Support", "Online Booking", "Instant Confirmation"];
const facilities = ["AC Bus Travel", "Hotel Stay", "Morning Tea", "Breakfast", "Lunch", "Dinner", "Mineral Water", "Medical Kit", "Experienced Tour Guide", "Charging Ports", "Pushback Seats", "Luggage Space", "Live GPS Tracking"];
const faqs = [
  ["How can I book?", "Use the booking form or call our support team. We confirm seats after checking route availability."],
  ["What is included?", "Bus travel, hotel stay, refreshments, sightseeing support, and guide assistance are included in most packages."],
  ["Can I cancel?", "Yes. Cancellation terms vary by package and departure date."],
  ["Are meals included?", "Most tours include breakfast, lunch, dinner, tea, and mineral water as listed in the package."],
  ["Are hotels included?", "Yes, standard clean hotel stays are included unless a package states otherwise."],
  ["Pickup locations?", "Pickup points are shared after booking confirmation based on your departure city."],
  ["Senior citizen discount?", "Selected tours include senior citizen support and seasonal discounts."],
  ["Children policy?", "Children can travel with guardians. Pricing depends on age and seat requirement."],
  ["Refund policy?", "Refunds follow the package policy and payment timeline."],
  ["Emergency contact?", "Every confirmed traveler receives a 24x7 route coordinator number."]
];
const testimonials = [
  ["AS", "Anita Sharma", "Our Kashi tour felt very well managed. The bus was clean and the guide helped my parents at every stop."],
  ["RP", "Rohan Patel", "Transparent pricing, good hotel, and timely darshan planning. A very polished travel experience."],
  ["MK", "Meera Kapoor", "The Vrindavan weekend package was affordable and comfortable. I would book again for Ayodhya."]
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

function renderDestinations(filter = "All") {
  const grid = $("#destinationsGrid");
  const list = filter === "All" ? destinations : destinations.filter((item) => item[4] === filter);
  grid.innerHTML = list.map(([name, desc, duration, price, , icon]) => `
    <article class="card reveal">
      <div class="card-media"><span>${icon}</span></div>
      <div class="card-body">
        <h3>${name}</h3>
        <p>${desc}</p>
        <div class="meta"><span>${duration}</span><span>${price}</span></div>
        <button class="outline-btn explore" data-place="${name}">Explore</button>
      </div>
    </article>
  `).join("");
  observeReveals();
}

function renderFilters() {
  const categories = ["All", ...new Set(destinations.map((item) => item[4]))];
  $("#filters").innerHTML = categories.map((cat, index) => `<button class="${index === 0 ? "active" : ""}" data-filter="${cat}">${cat}</button>`).join("");
  $("#filters").addEventListener("click", (event) => {
    if (!event.target.matches("button")) return;
    $$("#filters button").forEach((button) => button.classList.remove("active"));
    event.target.classList.add("active");
    renderDestinations(event.target.dataset.filter);
  });
}

function renderPackages(search = "") {
  const query = search.toLowerCase();
  const list = packages.filter((pkg) => [pkg.name, pkg.bus, pkg.price].join(" ").toLowerCase().includes(query));
  $("#packagesGrid").innerHTML = list.map((pkg, index) => `
    <article class="card reveal">
      <div class="card-media"><span>${pkg.icon}</span></div>
      <div class="card-body">
        <h3>${pkg.name}</h3>
        <p>${pkg.days} · ${pkg.bus}</p>
        <div class="meta"><span>${pkg.price}</span><span>${pkg.seats} seats</span></div>
        <ul class="package-list">
          <li>Hotel Included</li><li>Meals Included</li><li>Refreshments Included</li>
          <li>Sightseeing Included</li><li>Guide Included</li>
        </ul>
        <div class="card-actions">
          <a class="btn btn-small" href="#booking">Book Now</a>
          <button class="outline-btn itinerary" data-index="${index}">View Itinerary</button>
        </div>
      </div>
    </article>
  `).join("");
  observeReveals();
}

function renderSimpleLists() {
  $("#featureGrid").innerHTML = features.map((item) => `<article class="feature-card reveal"><span class="icon">✓</span><h3>${item}</h3></article>`).join("");
  $("#facilityGrid").innerHTML = facilities.map((item) => `<div class="facility-item reveal"><span class="icon">✦</span><strong>${item}</strong></div>`).join("");
  $("#destinationSelect").innerHTML = destinations.map(([name]) => `<option>${name}</option>`).join("");
  $("#faqList").innerHTML = faqs.map(([q, a]) => `<div class="faq-item reveal"><button class="faq-question">${q}<span>+</span></button><div class="faq-answer">${a}</div></div>`).join("");
}

function openItinerary(name) {
  $("#modalTitle").textContent = name;
  $("#modalBody").innerHTML = `
    <div class="day-card"><h3>Day 1</h3><p>Departure, temple visit, lunch, hotel check-in, evening aarti, and dinner.</p></div>
    <div class="day-card"><h3>Day 2</h3><p>Breakfast, guided sightseeing, local shopping, departure, and return journey.</p></div>
  `;
  $("#itineraryModal").classList.add("open");
}

let revealObserver;
function observeReveals() {
  if (!revealObserver) {
    revealObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add("visible");
      });
    }, { threshold: 0.12 });
  }
  $$(".reveal:not(.visible)").forEach((el) => revealObserver.observe(el));
}

function animateCounters() {
  $("[data-count]") && $$("[data-count]").forEach((counter) => {
    const target = Number(counter.dataset.count);
    let current = 0;
    const step = Math.max(1, Math.ceil(target / 90));
    const tick = setInterval(() => {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(tick);
      }
      counter.textContent = target > 999 ? current.toLocaleString("en-IN") + "+" : current + "+";
    }, 18);
  });
}

function initTestimonials() {
  let index = 0;
  $("#testimonialSlider").innerHTML = `<div class="testimonial-track">${testimonials.map(([initials, name, text]) => `
    <article class="testimonial-card">
      <div class="avatar">${initials}</div><div class="stars">★★★★★</div>
      <p>"${text}"</p><h3>${name}</h3>
    </article>`).join("")}</div>`;
  setInterval(() => {
    index = (index + 1) % testimonials.length;
    $(".testimonial-track").style.transform = `translateX(-${index * 100}%)`;
  }, 4200);
}

function initEvents() {
  $("#menuToggle").addEventListener("click", () => {
    const open = $("#navLinks").classList.toggle("open");
    $("#menuToggle").setAttribute("aria-expanded", open);
  });
  $("#themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    $("#themeToggle").textContent = document.body.classList.contains("dark") ? "☀" : "☾";
  });
  $("#packageSearch").addEventListener("input", (event) => renderPackages(event.target.value));
  document.addEventListener("click", (event) => {
    if (event.target.matches(".itinerary")) openItinerary(packages[event.target.dataset.index].name);
    if (event.target.matches(".explore")) {
      $("#destinationSelect").value = event.target.dataset.place;
      showToast(`${event.target.dataset.place} selected for booking`);
      location.hash = "booking";
    }
    if (event.target.closest(".faq-question")) event.target.closest(".faq-item").classList.toggle("open");
  });
  $("#modalClose").addEventListener("click", () => $("#itineraryModal").classList.remove("open"));
  $("#itineraryModal").addEventListener("click", (event) => {
    if (event.target.id === "itineraryModal") $("#itineraryModal").classList.remove("open");
  });
  $("#bookingForm").addEventListener("submit", (event) => {
    event.preventDefault();
    if (!event.currentTarget.checkValidity()) {
      event.currentTarget.reportValidity();
      return;
    }
    $("#formMessage").textContent = "Success! Your booking request has been received.";
    showToast("Booking request submitted");
    event.currentTarget.reset();
  });
  $("#searchForm").addEventListener("submit", (event) => {
    event.preventDefault();
    showToast("Matching packages are ready below");
    location.hash = "packages";
  });
  $("#newsletter").addEventListener("submit", (event) => {
    event.preventDefault();
    showToast("Newsletter subscription added");
    event.currentTarget.reset();
  });
  $("#backTop").addEventListener("click", () => scrollTo({ top: 0, behavior: "smooth" }));
}

function initScroll() {
  const links = $$(".nav-links a");
  window.addEventListener("scroll", () => {
    const max = document.documentElement.scrollHeight - innerHeight;
    $("#progress").style.width = `${(scrollY / max) * 100}%`;
    $("#backTop").classList.toggle("show", scrollY > 500);
    let current = "";
    $$("main section[id]").forEach((section) => {
      if (scrollY >= section.offsetTop - 130) current = section.id;
    });
    links.forEach((link) => link.classList.toggle("active", link.getAttribute("href") === `#${current}`));
  });
}

function initTyping() {
  const words = ["Faith", "Comfort", "Devotion", "Trust"];
  let index = 0;
  setInterval(() => {
    index = (index + 1) % words.length;
    $("#typed").textContent = words[index];
  }, 1900);
}

window.addEventListener("load", () => {
  setTimeout(() => $("#loader").classList.add("hide"), 450);
  animateCounters();
});

renderFilters();
renderDestinations();
renderPackages();
renderSimpleLists();
initTestimonials();
initEvents();
initScroll();
initTyping();
observeReveals();
