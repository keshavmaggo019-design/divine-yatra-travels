# Assets

This folder contains website media files.

- `images/hero-bus-temple.png` is used as the homepage hero background.

Keep the `assets` folder beside `index.html`, `style.css`, and `script.js`.
