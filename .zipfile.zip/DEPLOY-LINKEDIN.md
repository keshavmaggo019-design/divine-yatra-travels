# Create a Public Website Link for LinkedIn

Your local file path will not work on LinkedIn. You need to host the website online.

## Best Free Option: GitHub Pages

1. Go to GitHub and create a new repository named:

```text
divine-yatra-travels
```

2. Upload these project files to the repository:

```text
index.html
style.css
script.js
assets/
README.md
```

3. Open your GitHub repository.

4. Go to:

```text
Settings > Pages
```

5. Under **Build and deployment**, select:

```text
Source: Deploy from a branch
Branch: main
Folder: /root
```

6. Click **Save**.

7. Wait 1-3 minutes. GitHub will create a public link like:

```text
https://your-username.github.io/divine-yatra-travels/
```

That is the link you can post on LinkedIn.

## LinkedIn Post Text

```text
I built a modern responsive frontend website using HTML, CSS, and Vanilla JavaScript.

Project: Divine Yatra Travels
Theme: Affordable spiritual bus journeys across India

Features:
- Responsive landing page
- Destination filters
- Package search
- Booking form validation
- FAQ accordion
- Dark mode
- Itinerary modal
- Scroll animations
- Testimonial slider

Live Website: https://your-username.github.io/divine-yatra-travels/
```
