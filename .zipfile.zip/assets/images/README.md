# Images

Website image files go here.

Current image:

- `hero-bus-temple.png`
