# Divine Yatra Travels

Modern responsive frontend website for a fictional pilgrimage bus travel company.

## Files

- `index.html` - website structure and sections
- `style.css` - complete responsive design
- `script.js` - interactivity, filters, modal, form validation, slider
- `assets/images/hero-bus-temple.png` - hero background image

## Preview

Run this command in the VS Code terminal:

```powershell
py -m http.server 5177
```

Then open:

```text
http://localhost:5177
```
